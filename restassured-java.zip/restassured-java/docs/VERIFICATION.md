# Standalone repository verification

This folder contains only **restassured-java**. It has its own included demo application, test runner, environment examples, schemas, reporting, CI and dependency definitions. No other framework folder is required.

After separating it from the original combined repository, installed its dependencies and ran its own local fixture/test command with four workers. Result: **API 10, all passed; zero failures and zero skipped tests**.

```sh
node scripts/run.mjs api -o -DWORKERS=4
```

Java was compiled with JDK 21 and Maven Wrapper; Maven offline mode was used for the standalone test run. The JavaScript project was installed from its pinned npm lockfile. All repositories have their own ESLint/Prettier tooling for included JavaScript, fixture and documentation files; Java uses Maven Spotless.

Browser checks used the installed system Chromium executable through an explicit BROWSER_EXECUTABLE_PATH override. Matching browser downloads were previously denied by cloud network policy. Firefox, WebKit and video capture remain unverified; CI and Windows/macOS execution have not been run in this cloud. On your local computer install the selected browser using the project README commands. API-only tests do not require browser binaries.

Reports are generated locally and excluded from Git/ZIP distributions: Java module target/surefire-reports, target/allure-results and target/reports; Java web artifacts under web-tests/target/artifacts; JavaScript reports/<selection> and artifacts/<selection>. The original implementation also verified smoke/specific filters, zero-test nonzero exits, controlled-failure screenshot/trace capture, retries, trace sanitization, and fixture process cleanup. Those earlier results are not presented as newly repeated standalone checks.

The local standalone folder/ZIP is prepared. GitHub creation/upload depends on api.github.com being enabled in this cloud. This document does not claim the new repository or workflow has already been published/run.
