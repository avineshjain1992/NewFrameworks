import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
const root = fileURLToPath(new URL("../", import.meta.url));
const [scope = "all", ...extra] = process.argv.slice(2);
if (!["api", "web", "all"].includes(scope))
  throw new Error("Select api, web or all");
const windows = process.platform === "win32";
const executable = windows ? "mvnw.cmd" : "./mvnw";
const args = ["-B", "-ntp", "clean", "test"];
if (scope === "api") args.push("-pl", "api-tests", "-am");
if (scope === "web") args.push("-pl", "web-tests", "-am");
args.push(...extra);
const shell = windows;
const child = spawn(executable, args, {
  cwd: root,
  env: process.env,
  stdio: "inherit",
  shell,
});
for (const signal of ["SIGINT", "SIGTERM"])
  process.once(signal, () => child.kill(signal));
child.once("error", (error) => {
  console.error(error.message);
  process.exitCode = 1;
});
child.once("exit", (code) => {
  process.exitCode = code ?? 1;
});
