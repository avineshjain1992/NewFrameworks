import js from "@eslint/js";
export default [
  {
    ignores: [
      "**/target/**",
      "**/reports/**",
      "**/artifacts/**",
      "**/node_modules/**",
    ],
  },
  js.configs.recommended,
  {
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: {
        process: "readonly",
        console: "readonly",
        URL: "readonly",
        setTimeout: "readonly",
        clearTimeout: "readonly",
        fetch: "readonly",
        Buffer: "readonly",
      },
    },
  },
];
