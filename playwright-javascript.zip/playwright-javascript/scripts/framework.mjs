import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
const root = fileURLToPath(new URL("../", import.meta.url));
const [scope = "all", ...extra] = process.argv.slice(2);
if (!["api", "web", "all"].includes(scope))
  throw new Error("Select api, web or all");
const executable = process.execPath;
const args = ["scripts/test.mjs", scope, ...extra];
const shell = false;
const child = spawn(executable, args, {
  cwd: root,
  env: process.env,
  stdio: "inherit",
  shell,
});
for (const signal of ["SIGINT", "SIGTERM"])
  process.once(signal, () => child.kill(signal));
child.once("error", (error) => {
  console.error(error.message);
  process.exitCode = 1;
});
child.once("exit", (code) => {
  process.exitCode = code ?? 1;
});
